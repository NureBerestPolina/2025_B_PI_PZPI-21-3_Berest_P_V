export enum AccusationStatus {
    New = 'New',
    Rejected = 'Rejected',
    Accepted = 'Accepted',
  }