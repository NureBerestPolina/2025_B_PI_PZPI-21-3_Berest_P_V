import { Component } from '@angular/core';

@Component({
  selector: 'app-reached-accusation-limitation',
  templateUrl: './reached-accusation-limitation.component.html',
  styleUrl: './reached-accusation-limitation.component.css'
})
export class ReachedAccusationLimitationComponent {

}
