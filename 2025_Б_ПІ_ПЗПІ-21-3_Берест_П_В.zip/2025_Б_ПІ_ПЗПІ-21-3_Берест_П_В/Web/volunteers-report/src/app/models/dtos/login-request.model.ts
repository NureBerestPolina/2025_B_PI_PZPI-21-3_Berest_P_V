export interface LoginRequest {
    googleOAuthJwt: string;
}