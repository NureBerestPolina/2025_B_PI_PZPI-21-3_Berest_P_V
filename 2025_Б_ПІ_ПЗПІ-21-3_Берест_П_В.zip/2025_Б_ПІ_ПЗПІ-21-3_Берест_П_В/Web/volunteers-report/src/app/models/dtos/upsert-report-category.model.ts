export interface UpsertReportCategory {
    name: string;
    description: string;
}