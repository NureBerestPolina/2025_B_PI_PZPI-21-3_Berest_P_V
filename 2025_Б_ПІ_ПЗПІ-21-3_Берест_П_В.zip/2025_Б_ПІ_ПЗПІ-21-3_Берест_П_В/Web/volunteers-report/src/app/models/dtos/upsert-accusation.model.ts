export interface UpsertAccusation {
    userId: string;
    volunteerId: string;
    reasonDescription: string;
}