export interface CategoryCost {
    categoryName: string;
    costUsd: number;
}