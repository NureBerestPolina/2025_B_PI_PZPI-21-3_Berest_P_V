export enum Role {
    Administrator = 'administrator',
    User = 'user'
  }