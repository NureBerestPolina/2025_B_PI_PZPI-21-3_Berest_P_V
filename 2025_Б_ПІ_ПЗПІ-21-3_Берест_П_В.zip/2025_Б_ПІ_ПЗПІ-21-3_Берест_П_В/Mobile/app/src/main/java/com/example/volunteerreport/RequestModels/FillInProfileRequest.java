package com.example.volunteerreport.RequestModels;

import java.util.UUID;

public class FillInProfileRequest {
    public UUID userId;
    public String nickname;
    public String shortInfo;
    public String bankLink;
    public String helpInfo;

    public FillInProfileRequest(UUID userId, String nickname, String shortInfo, String bankLink, String helpInfo) {
        this.userId = userId;
        this.nickname = nickname;
        this.shortInfo = shortInfo;
        this.bankLink = bankLink;
        this.helpInfo = helpInfo;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getShortInfo() {
        return shortInfo;
    }

    public void setShortInfo(String shortInfo) {
        this.shortInfo = shortInfo;
    }

    public String getBankLink() {
        return bankLink;
    }

    public void setBankLink(String bankLink) {
        this.bankLink = bankLink;
    }

    public String getHelpInfo() {
        return helpInfo;
    }

    public void setHelpInfo(String helpInfo) {
        this.helpInfo = helpInfo;
    }
}
