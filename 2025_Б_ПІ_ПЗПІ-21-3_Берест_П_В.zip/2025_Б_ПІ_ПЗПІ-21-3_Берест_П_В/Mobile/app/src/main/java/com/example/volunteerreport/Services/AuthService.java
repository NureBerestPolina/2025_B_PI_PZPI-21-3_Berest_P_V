package com.example.volunteerreport.Services;

import android.content.Context;

import com.example.volunteerreport.Constants.Constants;
import com.example.volunteerreport.Models.User;
import com.example.volunteerreport.RequestModels.FillInProfileRequest;
import com.example.volunteerreport.RequestModels.LoginRequest;
import com.example.volunteerreport.RequestModels.LoginResponse;
import com.example.volunteerreport.RequestModels.RegisterResponse;
import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AuthService {
    private static AuthService instance;
    private TokenStorageService tokenStorage;
    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private OkHttpClient client;
    private Gson gson;

    private AuthService(Context context) {
        tokenStorage = new TokenStorageService(context);
        client = new OkHttpClient();
        gson = new Gson();
    }

    public static AuthService getInstance(Context context) {
        if (instance == null) {
            instance = new AuthService(context);
        }
        return instance;
    }

    public LoginResponse login(LoginRequest loginRequest) {
        String json = gson.toJson(loginRequest);
        RequestBody body = RequestBody.create(json, JSON);

        Request request = new Request.Builder()
                .url(Constants.BASE_URL + "auth/login/volunteer")
                .post(body)
                .build();

        try {
            Response response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String responseBody = response.body().string();

                LoginResponse loginResponse = gson.fromJson(responseBody, LoginResponse.class);
                tokenStorage.saveToken(loginResponse.getToken());
                tokenStorage.saveRefreshToken(loginResponse.getRefreshToken());

                return loginResponse;
            }
        }
        catch (IOException e) {
            return null;
        }

        return null;
    }

    public boolean fillInVolunteerProfile(FillInProfileRequest profile) {
        String json = gson.toJson(profile);
        RequestBody body = RequestBody.create(json, JSON);

        Request request = new Request.Builder()
                .url(Constants.BASE_URL + "FillVolunteerProfile")
                .put(body)
                .build();

        try {
            Response response = client.newCall(request).execute();

            return response.isSuccessful();
        }
        catch (IOException e) {
            return false;
        }
    }

    public LoginResponse refreshToken(String token, String refreshToken) {
        String jsonBody = "{\"token\":\"" + token + "\", \"refreshToken\":\"" + refreshToken + "\"}";

        RequestBody requestBody = RequestBody.create(jsonBody, JSON);

        // Build the request
        Request request = new Request.Builder()
                .url(Constants.BASE_URL + "/auth/refresh-token")
                .post(requestBody)
                .build();

        try {
            Response response = client.newCall(request).execute();

            if (response.isSuccessful()) {
                String responseBody = response.body().string();

                LoginResponse loginResponse = gson.fromJson(responseBody, LoginResponse.class);
                tokenStorage.saveToken(loginResponse.getToken());
                tokenStorage.saveRefreshToken(loginResponse.getRefreshToken());

                return loginResponse;
            }
        }
        catch (IOException e) {
            return null;
        }

        return null;
    }

    public User getUser()
    {
        return tokenStorage.getUser();
    }

    public void logout() {
        tokenStorage.signOut();
    }
}
