package com.example.volunteerreport.RequestModels;

public class LoginResponse {
    public String token;
    public String refreshToken;

    public String getToken() {
        return token;
    }

    public String getRefreshToken() {
        return refreshToken;
    }
}
