package com.example.volunteerreport.Services;

import android.content.Context;

import com.example.volunteerreport.Constants.Constants;
import com.example.volunteerreport.Constants.ODataEndpointsNames;
import com.example.volunteerreport.Models.ReportDetail;
import com.example.volunteerreport.RequestModels.IdResponse;
import com.example.volunteerreport.RequestModels.MakeReportRequest;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ReportItemsService {
    private Context context;
    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private OkHttpClient client;
    private Gson gson;

    public ReportItemsService(Context сontext) {
        this.context = сontext;
        client = new OkHttpClient();
        gson = new Gson();
    }

    public void addReportItem(ReportDetail detail) {
        ODataService<ReportDetail> service = new ODataService<ReportDetail>(ReportDetail.class, context);
        ODataQueryBuilder builder = new ODataQueryBuilder();
        try {
            service.create(ODataEndpointsNames.DETAILS, detail);
        } catch (IOException e) {
        }
    }
}
