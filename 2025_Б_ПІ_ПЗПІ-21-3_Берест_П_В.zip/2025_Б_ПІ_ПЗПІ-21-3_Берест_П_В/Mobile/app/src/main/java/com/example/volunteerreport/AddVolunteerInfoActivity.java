package com.example.volunteerreport;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.volunteerreport.RequestModels.FillInProfileRequest;
import com.example.volunteerreport.Services.AuthService;

import java.util.UUID;

public class AddVolunteerInfoActivity extends AppCompatActivity {
    private Button registerButton;
    private UUID userId;
    private EditText nicknameInput, shortInfoInput, bankLinkInput, helpInfoInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_volunteer_info);

        Intent intent = getIntent();
        userId = UUID.fromString(intent.getStringExtra("userId"));

        registerButton = (Button) findViewById(R.id.register_btn);
        nicknameInput = (EditText) findViewById(R.id.register_nickname_input);
        shortInfoInput = (EditText) findViewById(R.id.register_short_info);
        bankLinkInput = (EditText) findViewById(R.id.register_bank_link);
        helpInfoInput = (EditText) findViewById(R.id.register_help_info);

        nicknameInput.setText("Appol");
        shortInfoInput.setText("Brave enough to be helpful! From Kharkiv with love");
        bankLinkInput.setText("https://link123");
        helpInfoInput.setText("Support me also on my Instagram berest_polinka");

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isInputValid())
                {
                    attemptFillInVolunteerProfile();
                }
                else{
                    Toast.makeText(AddVolunteerInfoActivity.this, getResources().getString(R.string.validation_fail), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean isInputValid()
    {
        boolean isNicknameValid = isNicknameValid(nicknameInput);
        boolean isShortInfoValid = isInfoValid(shortInfoInput);
        boolean isBankLinkValid = isLinkValid(bankLinkInput);
        boolean isHelpInfoValid = isInfoValid(helpInfoInput);

        return isNicknameValid
                && isShortInfoValid
                && isBankLinkValid
                && isHelpInfoValid;
    }

    private void attemptFillInVolunteerProfile() {
        String nickname = nicknameInput.getText().toString();
        String shortInfo = shortInfoInput.getText().toString();
        String bankLink = bankLinkInput.getText().toString();
        String helpInfo = helpInfoInput.getText().toString();

        boolean isRegistrationSuccessful = AuthService
                .getInstance(this)
                .fillInVolunteerProfile(new FillInProfileRequest(
                        userId,
                        nickname,
                        shortInfo,
                        bankLink,
                        helpInfo
                ));

        if (isRegistrationSuccessful) {
            Intent intent = new Intent(AddVolunteerInfoActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
        else {
            Toast.makeText(this, getResources().getString(R.string.universal_fail), Toast.LENGTH_SHORT).show();
        }
    }

    private static boolean isNicknameValid(EditText nicknameInput) {
        return nicknameInput.getText().toString().trim().length() > 2;
    }

    private static boolean isInfoValid(EditText infoInput) {
        return infoInput.getText().toString().trim().length() >= 10;
    }

    private static boolean isLinkValid(EditText linkInput) {
        String link = linkInput.getText().toString().trim();
        String urlPattern = "^(http|https)://.*$";
        return link.matches(urlPattern);
    }
}