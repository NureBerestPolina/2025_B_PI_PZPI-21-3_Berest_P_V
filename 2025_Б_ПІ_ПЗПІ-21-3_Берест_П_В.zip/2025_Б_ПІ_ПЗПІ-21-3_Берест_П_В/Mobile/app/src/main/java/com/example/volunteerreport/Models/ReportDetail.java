package com.example.volunteerreport.Models;

import androidx.annotation.NonNull;

import java.util.UUID;

public class ReportDetail {
    public ReportDetail() {}

    public ReportDetail(UUID id, UUID reportId, Report report, UUID categoryId, ReportCategory category, double amount, String measurementUnit, double costUsd) {
        this.id = id;
        this.reportId = reportId;
        this.report = report;
        this.categoryId = categoryId;
        this.category = category;
        this.amount = amount;
        this.measurementUnit = measurementUnit;
        this.costUsd = costUsd;
    }

    public ReportDetail(UUID reportId, UUID categoryId, double amount, String measurementUnit, double costUsd) {
        this.reportId = reportId;
        this.categoryId = categoryId;
        this.amount = amount;
        this.measurementUnit = measurementUnit;
        this.costUsd = costUsd;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getReportId() {
        return reportId;
    }

    public void setReportId(UUID reportId) {
        this.reportId = reportId;
    }

    public Report getReport() {
        return report;
    }

    public void setReport(Report report) {
        this.report = report;
    }

    public UUID getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(UUID categoryId) {
        this.categoryId = categoryId;
    }

    public ReportCategory getCategory() {
        return category;
    }

    public void setCategory(ReportCategory category) {
        this.category = category;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getMeasurementUnit() {
        return measurementUnit;
    }

    public void setMeasurementUnit(String measurementUnit) {
        this.measurementUnit = measurementUnit;
    }

    public double getCostUsd() {
        return costUsd;
    }

    public void setCostUsd(double costUsd) {
        this.costUsd = costUsd;
    }

    private UUID id;
    private UUID reportId;
    private Report report;
    private UUID categoryId;
    private ReportCategory category;
    private double amount;
    private String measurementUnit;
    private double costUsd;

    @NonNull
    @Override
    public String toString() {
        return category.name + ": "
                + amount + " (" + measurementUnit + "), "
                + costUsd + "$";
    }
}
