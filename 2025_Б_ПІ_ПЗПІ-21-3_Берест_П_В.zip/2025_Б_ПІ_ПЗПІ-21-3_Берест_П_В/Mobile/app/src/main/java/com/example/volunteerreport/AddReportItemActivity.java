package com.example.volunteerreport;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.volunteerreport.Models.ReportCategory;
import com.example.volunteerreport.Models.ReportDetail;
import com.example.volunteerreport.Services.CategoriesService;
import com.example.volunteerreport.Services.ReportItemsService;
import com.example.volunteerreport.Services.ReportsService;

import java.util.UUID;

public class AddReportItemActivity extends AppCompatActivity {
    UUID newReportId;
    ReportCategory selectedCategory;
    String measurementUnit;
    Spinner volunteerHelpUnitsSpinner, categoriesSpinner;
    Button addAnotherItemBtn, finishReportBtn;
    EditText amountEditText, costEditText;
    ReportsService reportsService;
    CategoriesService categoriesService;
    ReportItemsService detailsService;
    ReportDetail newDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_report_item);

        Intent intent = getIntent();
        newReportId = UUID.fromString(intent.getStringExtra("reportId"));

        initSpinners();

        amountEditText = findViewById(R.id.item_amount);
        costEditText = findViewById(R.id.cost);

        addAnotherItemBtn = findViewById(R.id.add_another_report_item_btn);
        finishReportBtn = findViewById(R.id.finish_report_btn);

        finishReportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formDetail();

                detailsService = new ReportItemsService(AddReportItemActivity.this);
                detailsService.addReportItem(newDetail);

                Toast.makeText(getApplicationContext(), getResources().getString(R.string.succesful_report_adding), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(AddReportItemActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });

        addAnotherItemBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                formDetail();

                detailsService = new ReportItemsService(AddReportItemActivity.this);
                detailsService.addReportItem(newDetail);

                Toast.makeText(getApplicationContext(), getResources().getString(R.string.succesful_report_item_adding), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(AddReportItemActivity.this, AddReportItemActivity.class);
                intent.putExtra("reportId", newReportId.toString());
                startActivity(intent);
                finish();
            }
        });
    }

    private void initSpinners() {
        volunteerHelpUnitsSpinner = findViewById(R.id.measurement_units_spinner);
        categoriesSpinner = findViewById(R.id.categories_spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, // Context
                R.array.volunteer_help_units,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        volunteerHelpUnitsSpinner.setAdapter(adapter);
        volunteerHelpUnitsSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                measurementUnit = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                measurementUnit = null;
            }
        });

        categoriesService = new CategoriesService(this);
        categoriesService.seedCategories(categoriesSpinner);

        categoriesSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCategory = (ReportCategory) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedCategory = null;
            }
        });
    }

    private void formDetail()
    {
        newDetail = new ReportDetail();

        newDetail.setReportId(newReportId);
        newDetail.setCategoryId(selectedCategory.getId());
        newDetail.setAmount(Integer.parseInt(amountEditText.getText().toString()));
        newDetail.setCostUsd(Double.parseDouble(costEditText.getText().toString()));
        newDetail.setMeasurementUnit(measurementUnit);
    }
}