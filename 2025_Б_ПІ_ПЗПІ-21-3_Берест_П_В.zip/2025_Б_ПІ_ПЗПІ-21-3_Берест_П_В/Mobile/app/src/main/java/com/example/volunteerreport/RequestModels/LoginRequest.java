package com.example.volunteerreport.RequestModels;

public class LoginRequest {
    public LoginRequest(String googleOAuthJwt) {
        this.googleOAuthJwt = googleOAuthJwt;
    }

    public String googleOAuthJwt;
}

