package com.example.volunteerreport.RequestModels;

public class IdResponse {
    public String id;
}
