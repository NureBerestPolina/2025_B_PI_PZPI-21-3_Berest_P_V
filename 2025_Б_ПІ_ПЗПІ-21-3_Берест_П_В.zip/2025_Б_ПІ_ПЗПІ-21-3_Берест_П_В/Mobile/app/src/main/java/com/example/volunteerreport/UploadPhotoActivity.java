package com.example.volunteerreport;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;

import com.example.volunteerreport.RequestModels.UrlResponse;
import com.example.volunteerreport.Services.ReportsService;

import java.io.File;

public class UploadPhotoActivity extends AppCompatActivity {

    private final int GALLERY_REQUEST_CODE = 1000;
    ImageView imgPreview;
    Button uploadBtn;
    Uri selectedImageUri;
    TextView plagiarismWarning;

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_photo);
        verifyStoragePermissions(this);

        imgPreview = findViewById(R.id.photo_preview);
        Button selectBtn = findViewById(R.id.select_btn);
        uploadBtn = findViewById(R.id.upload_btn);
        plagiarismWarning = findViewById(R.id.plagiarism_warning);

        selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentGallery = new Intent(Intent.ACTION_PICK);
                intentGallery.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intentGallery, GALLERY_REQUEST_CODE);
            }
        });

        uploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedImageUri != null) {
                    File photoFile = new File(getRealPathFromURI(selectedImageUri));
                    plagiarismWarning.setVisibility(View.GONE);

                    if (photoFile.exists()) {
                        ReportsService service = new ReportsService(UploadPhotoActivity.this);
                        String response = service.uploadPhoto(photoFile);

                        if (response != null && !response.isEmpty()) {
                            Toast.makeText(UploadPhotoActivity.this, "Image uploaded" , Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(UploadPhotoActivity.this, AddReportActivity.class);
                            intent.putExtra("photoUrl", response);
                            startActivity(intent);
                            finish();
                        } else if (response.isEmpty()) {
                            plagiarismWarning.setVisibility(View.VISIBLE);
                            Toast.makeText(UploadPhotoActivity.this, "Photo is plagiarized! Add another one", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(UploadPhotoActivity.this, "Upload failed", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(UploadPhotoActivity.this, "Invalid file", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == GALLERY_REQUEST_CODE) {
            selectedImageUri = data.getData();
            imgPreview.setImageURI(data.getData());
            uploadBtn.setVisibility(View.VISIBLE);
        }
    }

    private String getRealPathFromURI(Uri contentUri) {
        String result = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                result = cursor.getString(columnIndex);
            }
            cursor.close();
        }
        return result;
    }

    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }
}