package com.example.volunteerreport.RequestModels;

import java.util.UUID;

public class MakeReportRequest {

    public MakeReportRequest(String description, String direction, UUID userId, String photoUrl) {
        this.description = description;
        this.direction = direction;
        this.userId = userId;
        this.photoUrl = photoUrl;
    }
    public String description;
    public String direction;
    public UUID userId;
    public String photoUrl;
}
