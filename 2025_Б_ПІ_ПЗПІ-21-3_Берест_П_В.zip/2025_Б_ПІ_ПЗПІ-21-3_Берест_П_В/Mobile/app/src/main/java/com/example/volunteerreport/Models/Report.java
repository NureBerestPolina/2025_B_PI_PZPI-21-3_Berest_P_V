package com.example.volunteerreport.Models;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class Report {
    public Report(UUID id, String description, String direction, UUID volunteerId, Volunteer volunteer, Date created, Date modified, boolean isDeleted, String photoUrl, List<ReportDetail> reportDetails) {
        this.id = id;
        this.description = description;
        this.direction = direction;
        this.volunteerId = volunteerId;
        this.volunteer = volunteer;
        this.created = created;
        this.modified = modified;
        this.isDeleted = isDeleted;
        this.photoUrl = photoUrl;
        this.reportDetails = reportDetails;
    }

    public Report(String description, String direction, UUID volunteerId, String photoUrl) {
        this.description = description;
        this.direction = direction;
        this.volunteerId = volunteerId;
        this.photoUrl = photoUrl;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public UUID getVolunteerId() {
        return volunteerId;
    }

    public void setVolunteerId(UUID volunteerId) {
        this.volunteerId = volunteerId;
    }

    public Volunteer getVolunteer() {
        return volunteer;
    }

    public void setVolunteer(Volunteer volunteer) {
        this.volunteer = volunteer;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public List<ReportDetail> getReportDetails() {
        return reportDetails;
    }

    public void setReportDetails(List<ReportDetail> reportDetails) {
        this.reportDetails = reportDetails;
    }

    private UUID id;
    private String description;
    private String direction;
    private UUID volunteerId;
    private Volunteer volunteer;
    private Date created;
    private Date modified;
    private boolean isDeleted;
    private String photoUrl;
    private List<ReportDetail> reportDetails;

    @NonNull
    @Override
    public String toString() {
        StringBuilder res = new StringBuilder();

        res.append("\uD83D\uDCCD" + this.direction
                + "\n" + this.description + "\n\n");

        for (ReportDetail detail:
                reportDetails) {
            res.append(" ◾ " + detail.toString() + "\n");
        }

        return res.toString();
    }
}
