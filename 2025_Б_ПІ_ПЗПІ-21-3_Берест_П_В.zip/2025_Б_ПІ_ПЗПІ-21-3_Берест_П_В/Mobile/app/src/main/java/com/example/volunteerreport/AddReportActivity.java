package com.example.volunteerreport;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.volunteerreport.Models.Report;
import com.example.volunteerreport.RequestModels.MakeReportRequest;
import com.example.volunteerreport.Services.AuthService;
import com.example.volunteerreport.Services.ReportsService;

import java.util.UUID;

public class AddReportActivity extends AppCompatActivity {
    String selectedPhotoUrl;
    UUID userId, createdReportId;
    MakeReportRequest newReport;
    private Button createReportButton;
    private EditText descriptionInput, directionInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_report);

        Intent intent = getIntent();
        selectedPhotoUrl = intent.getStringExtra("photoUrl");
        userId = AuthService.getInstance(AddReportActivity.this).getUser().getId();

        createReportButton = (Button) findViewById(R.id.create_report_btn);
        descriptionInput = (EditText) findViewById(R.id.report_description);
        directionInput = (EditText) findViewById(R.id.report_direction);

        descriptionInput.setText("Description long enough pffffffffffffffffffffffffffffff");
        directionInput.setText("Kharkiv region");

        createReportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (inputIsValid(descriptionInput.getText().toString(), directionInput.getText().toString()) &&
                selectedPhotoUrl != null &&
                userId != null) {
                    newReport = new MakeReportRequest(
                            descriptionInput.getText().toString(),
                            directionInput.getText().toString(),
                            userId,
                            selectedPhotoUrl);

                    ReportsService service = new ReportsService(AddReportActivity.this);
                    String response = service.makeReport(newReport);

                    if (response != null) {
                        Intent intent = new Intent(AddReportActivity.this, AddReportItemActivity.class);
                        intent.putExtra("reportId", response);
                        startActivity(intent);
                        finish();
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(), getResources().getString(R.string.invalid_data_input), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean inputIsValid(String description, String direction)
    {
        if (description.length() > 5 && direction.length() > 5)
            return true;
        return false;
    }
}