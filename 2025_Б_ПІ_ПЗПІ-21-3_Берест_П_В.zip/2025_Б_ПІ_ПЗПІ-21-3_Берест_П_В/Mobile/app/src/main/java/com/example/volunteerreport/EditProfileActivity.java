package com.example.volunteerreport;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.volunteerreport.Constants.ODataEndpointsNames;
import com.example.volunteerreport.Models.Report;
import com.example.volunteerreport.Models.Volunteer;
import com.example.volunteerreport.RequestModels.FillInProfileRequest;
import com.example.volunteerreport.Services.AuthService;
import com.example.volunteerreport.Services.ODataQueryBuilder;
import com.example.volunteerreport.Services.ODataService;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class EditProfileActivity extends AppCompatActivity {
    private Button updateButton;
    private UUID userId;
    private EditText nicknameInput, shortInfoInput, bankLinkInput, helpInfoInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        userId = AuthService.getInstance(EditProfileActivity.this).getUser().getId();

        updateButton = (Button) findViewById(R.id.update_profile_btn);
        nicknameInput = (EditText) findViewById(R.id.update_nickname_input);
        shortInfoInput = (EditText) findViewById(R.id.update_short_info);
        bankLinkInput = (EditText) findViewById(R.id.update_bank_link);
        helpInfoInput = (EditText) findViewById(R.id.update_help_info);

        outputVolunteerInfo(userId);

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isInputValid())
                {
                    attemptFillInVolunteerProfile();
                }
                else{
                    Toast.makeText(EditProfileActivity.this, getResources().getString(R.string.validation_fail), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void outputVolunteerInfo(UUID userId) {
        Volunteer volunteer = getVolunteerInfo(userId);

        if (volunteer == null) {
            Toast.makeText(this, getResources().getString(R.string.universal_fail), Toast.LENGTH_SHORT).show();
            return;
        }

        nicknameInput.setText(volunteer.nickname);
        shortInfoInput.setText(volunteer.shortInfo);
        bankLinkInput.setText(volunteer.bankLink);
        helpInfoInput.setText(volunteer.helpInfo);
    }

    private Volunteer getVolunteerInfo(UUID userId) {
        ODataService<Volunteer> t = new ODataService<Volunteer>(Volunteer.class, this);

        ODataQueryBuilder builder = new ODataQueryBuilder();
        builder.filter("userId eq " + userId.toString());

        List<Volunteer> res;

        try {
            res = t.getAll(ODataEndpointsNames.VOLUNTEERS, builder);
        } catch (IOException e) {
            res = null;
        }

        return res.get(0);
    }

    private boolean isInputValid()
    {
        boolean isNicknameValid = isNicknameValid(nicknameInput);
        boolean isShortInfoValid = isInfoValid(shortInfoInput);
        boolean isBankLinkValid = isLinkValid(bankLinkInput);
        boolean isHelpInfoValid = isInfoValid(helpInfoInput);

        return isNicknameValid
                && isShortInfoValid
                && isBankLinkValid
                && isHelpInfoValid;
    }

    private void attemptFillInVolunteerProfile() {
        String nickname = nicknameInput.getText().toString();
        String shortInfo = shortInfoInput.getText().toString();
        String bankLink = bankLinkInput.getText().toString();
        String helpInfo = helpInfoInput.getText().toString();

        boolean isRegistrationSuccessful = AuthService
                .getInstance(this)
                .fillInVolunteerProfile(new FillInProfileRequest(
                        userId,
                        nickname,
                        shortInfo,
                        bankLink,
                        helpInfo
                ));

        if (isRegistrationSuccessful) {
            Intent intent = new Intent(EditProfileActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        }
        else {
            Toast.makeText(this, getResources().getString(R.string.universal_fail), Toast.LENGTH_SHORT).show();
        }
    }

    private static boolean isNicknameValid(EditText nicknameInput) {
        return nicknameInput.getText().toString().trim().length() > 2;
    }

    private static boolean isInfoValid(EditText infoInput) {
        return infoInput.getText().toString().trim().length() >= 10;
    }

    private static boolean isLinkValid(EditText linkInput) {
        String link = linkInput.getText().toString().trim();
        String urlPattern = "^(http|https)://.*$";
        return link.matches(urlPattern);
    }
}