package com.example.volunteerreport.RequestModels;

public class UrlResponse {
    public String url;
}
