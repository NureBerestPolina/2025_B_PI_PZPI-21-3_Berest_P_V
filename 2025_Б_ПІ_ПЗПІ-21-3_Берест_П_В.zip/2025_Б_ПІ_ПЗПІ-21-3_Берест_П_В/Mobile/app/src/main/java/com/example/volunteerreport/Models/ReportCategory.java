package com.example.volunteerreport.Models;

import androidx.annotation.NonNull;

import java.util.Date;
import java.util.UUID;

public class ReportCategory {
    public ReportCategory(UUID id, String name, String description, Date created, Date modified, boolean isDeleted) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.created = created;
        this.modified = modified;
        this.isDeleted = isDeleted;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreated() {
        return created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean deleted) {
        isDeleted = deleted;
    }

    public UUID id;
    public String name;
    public String description;
    public Date created;
    public Date modified;
    public boolean isDeleted;

    @NonNull
    @Override
    public String toString() {
        return this.name;
    }
}
