package com.example.volunteerreport.Constants;

public class ODataEndpointsNames {
    public static final String USERS = "Users";
    public static final String VOLUNTEERS = "Volunteers";
    public static final String ACCUSATIONS = "Accusations";
    public static final String REPORTS = "Reports";
    public static final String CATEGORIES = "Categories";
    public static final String DETAILS = "ReportDetails";
}
