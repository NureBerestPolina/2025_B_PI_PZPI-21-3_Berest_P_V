package com.example.volunteerreport;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.volunteerreport.Constants.Role;
import com.example.volunteerreport.Models.User;
import com.example.volunteerreport.RequestModels.LoginRequest;
import com.example.volunteerreport.RequestModels.LoginResponse;
import com.example.volunteerreport.Services.AuthService;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

import java.util.UUID;

public class RegistrationActivity extends AppCompatActivity {
    private static final int RC_SIGN_IN = 123;
    private SignInButton registerButton;
    private GoogleSignInClient mGoogleSignInClient;
    private UUID userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .requestIdToken("843931615146-6pjg2cij08fpa4imdn6n6j7gtv20vg0n.apps.googleusercontent.com")
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        mGoogleSignInClient.signOut();

        registerButton = (SignInButton) findViewById(R.id.google_sign_in_button);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptRegister();
            }
        });
    }

    private void attemptRegister() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            //String email = account.getEmail();
            //Uri photoUrl = account.getPhotoUrl();
            //String name = account.getDisplayName();
            String tokenId = account.getIdToken();

            LoginResponse response = AuthService.getInstance(this).login(new LoginRequest(tokenId));

            if (response != null) {
                User user = AuthService.getInstance(this).getUser();
                userId = user.getId();
                Intent intent;
                String role = user.getRole();
                if (role.equals(String.valueOf(Role.volunteer)))
                {
                    intent = new Intent(RegistrationActivity.this, AddVolunteerInfoActivity.class);
                    intent.putExtra("userId", userId.toString());
                    startActivity(intent);
                    finish();
                }
                else {
                    Toast.makeText(this, getResources().getString(R.string.universal_fail), Toast.LENGTH_SHORT).show();
                }
            }
            else {
                Toast.makeText(this, getResources().getString(R.string.universal_fail), Toast.LENGTH_SHORT).show();
            }
        } catch (ApiException e) {
        }
    }
}