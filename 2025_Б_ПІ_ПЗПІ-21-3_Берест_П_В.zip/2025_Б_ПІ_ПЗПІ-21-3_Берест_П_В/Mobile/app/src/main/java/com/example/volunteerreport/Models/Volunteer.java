package com.example.volunteerreport.Models;

import java.util.Date;
import java.util.UUID;

public class Volunteer {
    public Volunteer(UUID id, UUID userId, User user, String nickname, String shortInfo, Date modified, boolean isBlocked, boolean isHidden, String bankLink, String helpInfo) {
        this.id = id;
        this.userId = userId;
        this.user = user;
        this.nickname = nickname;
        this.shortInfo = shortInfo;
        this.modified = modified;
        this.isBlocked = isBlocked;
        this.isHidden = isHidden;
        this.bankLink = bankLink;
        this.helpInfo = helpInfo;
    }

    public UUID getId() {
        return id;
    }

    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getShortInfo() {
        return shortInfo;
    }

    public void setShortInfo(String shortInfo) {
        this.shortInfo = shortInfo;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    public boolean isBlocked() {
        return isBlocked;
    }

    public boolean isHidden() {
        return isHidden;
    }

    public String getBankLink() {
        return bankLink;
    }

    public void setBankLink(String bankLink) {
        this.bankLink = bankLink;
    }

    public String getHelpInfo() {
        return helpInfo;
    }

    public void setHelpInfo(String helpInfo) {
        this.helpInfo = helpInfo;
    }

    public UUID id;
    public UUID userId;
    public User user;
    public String nickname;
    public String shortInfo;
    public Date modified;
    public boolean isBlocked;
    public boolean isHidden;
    public String bankLink;
    public String helpInfo;
}
