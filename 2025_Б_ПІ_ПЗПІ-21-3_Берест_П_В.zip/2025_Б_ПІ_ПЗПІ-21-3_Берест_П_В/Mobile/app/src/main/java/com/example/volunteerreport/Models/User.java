package com.example.volunteerreport.Models;

import java.util.Date;
import java.util.UUID;

public class User {
    public User(UUID id, String name, String email, String avatarUrl, String role, Date registerDate) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.avatarUrl = avatarUrl;
        this.role = role;
        RegisterDate = registerDate;
    }

    public UUID getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public String getRole() {
        return role;
    }

    public Date getRegisterDate() {
        return RegisterDate;
    }

    public UUID id;
    public String name;
    public String email;
    public String avatarUrl;
    public String role;
    public Date RegisterDate;
}
