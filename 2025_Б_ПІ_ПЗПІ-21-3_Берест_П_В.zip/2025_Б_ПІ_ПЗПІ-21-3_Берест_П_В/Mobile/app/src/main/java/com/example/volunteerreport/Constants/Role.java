package com.example.volunteerreport.Constants;

public enum Role {
    administrator,
    user,
    volunteer
}
