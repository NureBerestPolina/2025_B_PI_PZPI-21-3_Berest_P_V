package com.example.volunteerreport.RequestModels;

import java.util.UUID;

public class RegisterResponse {
    public UUID userId;
}
