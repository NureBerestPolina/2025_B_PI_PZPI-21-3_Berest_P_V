package com.example.volunteerreport.Services;

import android.content.Context;

import com.example.volunteerreport.Constants.Constants;
import com.example.volunteerreport.Constants.ODataEndpointsNames;
import com.example.volunteerreport.Models.ReportCategory;
import com.example.volunteerreport.RequestModels.FillInProfileRequest;
import com.example.volunteerreport.RequestModels.IdResponse;
import com.example.volunteerreport.RequestModels.LoginResponse;
import com.example.volunteerreport.RequestModels.MakeReportRequest;
import com.example.volunteerreport.RequestModels.UrlResponse;
import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ReportsService {
    private Context context;
    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private OkHttpClient client;
    private Gson gson;

    public ReportsService(Context сontext) {
        this.context = сontext;
        client = new OkHttpClient();
        gson = new Gson();
    }

    public String uploadPhoto(File file) {
        if (!file.exists()) {
            return null;
        }

        RequestBody fileBody = RequestBody.create(file, MediaType.parse("image/jpeg"));
        MultipartBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.getName(), fileBody)
                .build();

        Request request = new Request.Builder()
                .url(Constants.BASE_URL + ODataEndpointsNames.REPORTS + "/UploadPhoto")
                .post(requestBody)
                .build();

        try {
            Response response = client.newCall(request).execute();

            if (response.isSuccessful() && response.body() != null) {
                String responseBody = response.body().string();
                // JSON  {"url": "http://example.com/image.jpg"}
                UrlResponse urlResponse = gson.fromJson(responseBody, UrlResponse.class);
                return urlResponse.url;
            } else if (response.code() == 400) {
                return "";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public String makeReport(MakeReportRequest reportRequest) {
        String json = gson.toJson(reportRequest);
        RequestBody requestBody = RequestBody.create(json, MediaType.parse("application/json"));

        Request request = new Request.Builder()
                .url(Constants.BASE_URL + ODataEndpointsNames.REPORTS + "/MakeReport")
                .post(requestBody)
                .build();

        try {
            Response response = client.newCall(request).execute();

            if (response.isSuccessful() && response.body() != null) {
                String responseBody = response.body().string();
                // JSON  {"url": "http://example.com/image.jpg"}
                IdResponse idResponse = gson.fromJson(responseBody, IdResponse.class);
                return idResponse.id;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
