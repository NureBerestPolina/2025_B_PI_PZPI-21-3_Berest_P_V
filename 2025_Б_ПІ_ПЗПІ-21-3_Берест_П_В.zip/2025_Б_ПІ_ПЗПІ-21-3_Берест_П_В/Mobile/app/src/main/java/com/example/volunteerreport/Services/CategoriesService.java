package com.example.volunteerreport.Services;
import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.volunteerreport.Constants.ODataEndpointsNames;
import com.example.volunteerreport.Models.ReportCategory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CategoriesService {
    private Context context;

    public CategoriesService(Context сontext) {
        this.context = сontext;
    }
    public List<ReportCategory> getCategories() {
        List<ReportCategory> categories = new ArrayList<>();
        ODataService<ReportCategory> t = new ODataService<ReportCategory>(ReportCategory.class, context);
        ODataQueryBuilder builder = new ODataQueryBuilder();
        try {
            categories = t.getAll(ODataEndpointsNames.CATEGORIES, builder);
        } catch (IOException e) {
        }

        return categories;
    }

    public void seedCategories(Spinner categoriesSpinner) {
        List<ReportCategory> categories = this.getCategories();

        if (categories != null) {
            ArrayAdapter<ReportCategory> adapter =
                    new ArrayAdapter<>(context, android.R.layout.simple_spinner_item, categories);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            categoriesSpinner.setAdapter(adapter);
        }
    }
}
