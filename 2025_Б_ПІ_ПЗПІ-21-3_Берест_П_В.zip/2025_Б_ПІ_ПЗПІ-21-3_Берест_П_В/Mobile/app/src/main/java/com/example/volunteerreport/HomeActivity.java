package com.example.volunteerreport;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.volunteerreport.Constants.ODataEndpointsNames;
import com.example.volunteerreport.Models.Report;
import com.example.volunteerreport.Services.AuthService;
import com.example.volunteerreport.Services.ODataQueryBuilder;
import com.example.volunteerreport.Services.ODataService;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class HomeActivity extends AppCompatActivity {

    private ImageView logoutBtn, makeReportBtn, profileBtn;
    private TextView noReportsText;
    List<Report> reportList;
    private LinearLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        logoutBtn = (ImageView) findViewById(R.id.logout_btn);
        makeReportBtn = (ImageView) findViewById(R.id.make_report_btn);
        profileBtn = (ImageView) findViewById(R.id.profile_btn);

        noReportsText = (TextView) findViewById(R.id.no_reports_made);
        layout = (LinearLayout) findViewById(R.id.reports_layout);

        outputOrders(AuthService.getInstance(HomeActivity.this).getUser().getId());

        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AuthService.getInstance(HomeActivity.this).logout();
                Intent main = new Intent(HomeActivity.this, MainActivity.class);
                startActivity(main);
                finish();
            }
        });

        profileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editProfile = new Intent(HomeActivity.this, EditProfileActivity.class);
                startActivity(editProfile);
                finish();
            }
        });

        makeReportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent order = new Intent(HomeActivity.this, UploadPhotoActivity.class);
                startActivity(order);
                finish();
            }
        });
    }

    private void outputOrders(UUID id) {
        reportList = getVolunteerReports(id);

        InsertToLayout(reportList);
    }

    private List<Report> getVolunteerReports(UUID id) {
        ODataService<Report> t = new ODataService<Report>(Report.class, this);

        ODataQueryBuilder builder = new ODataQueryBuilder();

        builder.expand("reportDetails($expand=category),volunteer");
        builder.filter("volunteer/userId eq " + id.toString());

        List<Report> res;

        try {
            res = t.getAll(ODataEndpointsNames.REPORTS, builder);
        } catch (IOException e) {
            res = null;
        }

        return res;
    }

    private void deleteReport(Report report) {
        ODataService<Report> t = new ODataService<Report>(Report.class, this);

        try {
            Report initReport = t.getById(ODataEndpointsNames.REPORTS, report.getId(), null);
            initReport.setDeleted(true);

            t.update(ODataEndpointsNames.REPORTS, initReport.getId().toString(), initReport);
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.succesful_report_delete), Toast.LENGTH_SHORT).show();
            restartActivity();
        } catch (IOException e) {
            Toast.makeText(getApplicationContext(), getResources().getString(R.string.failed_report_delete), Toast.LENGTH_SHORT).show();
        }
    }

    private void InsertToLayout(List<Report> reportList) {
        if(reportList==null || reportList.size() == 0){
            noReportsText.setVisibility(View.VISIBLE);
            return;
        }

        Collections.reverse(reportList);

        for (Report report : reportList) {
            TextView textView = new TextView(this);

            textView.setText(report.toString());
            textView.setTag(report.getId().toString());

            setDesign(textView, report.isDeleted());

            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String reportId = textView.getTag().toString();
                    String title = getString(R.string.report_title);
                    String description = makeFullDescription(report);

                    AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
                    builder.setTitle(title);
                    builder.setMessage(description);

                    if(!report.isDeleted())
                    {
                        builder.setNegativeButton(getResources().getString(R.string.delete_report) + " ❌", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                deleteReport(report);
                            }
                        });
                    }
                    builder.setNeutralButton(getResources().getString(R.string.close), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            });

            layout.addView(textView);
        }
    }

    private String makeFullDescription(Report order) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        return getResources().getString(R.string.about_report) + ": " +
                order.toString() +
                "\n\n" + getResources().getString(R.string.date_created) + " " + sdf.format(order.getCreated()) +
                " | " + getResources().getString(R.string.date_modified) + " " + sdf.format(order.getModified());
    }

    private void setDesign(TextView textView, boolean deleteStatus)
    {
        GradientDrawable border = new GradientDrawable();
        border.setColor(getColor(R.color.white)); // Correctly setting the color
        border.setCornerRadius(15); // Rounded corners
        border.setStroke(10, getReportColor(deleteStatus)); // Correctly setting stroke color

        // Set the drawable as the background of the TextView
        textView.setBackground(border);
        textView.setPadding(20, 10, 20, 10);

        Typeface font = ResourcesCompat.getFont(this, R.font.comfortaa);
        textView.setTypeface(font);
        textView.setTextSize(22);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(20, 20, 20, 0);
        textView.setLayoutParams(params);
    }

    private int getReportColor(boolean isDeleted)
    {
        return isDeleted ? getColor(R.color.red) : getColor(R.color.green); // Return int, not Color
    }

    private void restartActivity() {
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }
}