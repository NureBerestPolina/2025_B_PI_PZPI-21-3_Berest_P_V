﻿namespace EnRoute.API.Contracts.Auth.Requests;

public record LoginRequest(string googleOAuthJwt);