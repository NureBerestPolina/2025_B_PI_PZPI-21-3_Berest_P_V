﻿namespace VolunteerReport.Common.Configuration
{
    public class AdminSettings
    {
        public IEnumerable<string> Emails { get; set; }
    }
}
