﻿namespace VolunteerReport.Domain.Models.Interfaces
{
    public interface IODataEntity
    {
        Guid Id { get; set; }
    }
}
