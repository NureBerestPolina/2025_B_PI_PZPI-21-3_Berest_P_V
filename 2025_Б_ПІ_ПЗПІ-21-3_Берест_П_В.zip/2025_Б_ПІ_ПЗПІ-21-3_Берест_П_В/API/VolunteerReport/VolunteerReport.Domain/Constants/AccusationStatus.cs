﻿namespace EnRoute.Domain.Constants
{
    public enum AccusationStatus
    {
        New,
        Rejected,
        Accepted
    }
}
