﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VolunteerReport.Infrastructure.Dtos
{
    public class CategoryCost
    {
        public string CategoryName { get; set; }
        public decimal CostUsd { get; set; }
    }
}
